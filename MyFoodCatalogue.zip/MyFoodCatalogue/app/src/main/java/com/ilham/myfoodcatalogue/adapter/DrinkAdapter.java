package com.ilham.myfoodcatalogue.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.ilham.myfoodcatalogue.R;
import com.ilham.myfoodcatalogue.model.Drink;

import java.util.ArrayList;

public class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.viewHolder> {

    Context context;
    ArrayList<Drink> drinks;

    public DrinkAdapter(Context context, ArrayList<Drink> drinks) {
        this.context = context;
        this.drinks = drinks;
    }

    @NonNull
    @Override
    public DrinkAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item, parent, false);
        return new DrinkAdapter.viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DrinkAdapter.viewHolder holder, int i) {
        holder.title.setText(drinks.get(i).getName());

        Glide.with(context)
                .load(drinks.get(i).getPhoto())
                .apply(new RequestOptions().override(500, 250))
                .into(holder.img);

    }

    @Override
    public int getItemCount() {
        return drinks.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView img;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.card_title);
            img = itemView.findViewById(R.id.card_image);
        }
    }
}
